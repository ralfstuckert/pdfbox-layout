package rst.pdfbox.layout.elements;


public interface Element {


}
