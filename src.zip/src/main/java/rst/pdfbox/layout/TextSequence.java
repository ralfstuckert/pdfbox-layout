package rst.pdfbox.layout;


public interface TextSequence extends DrawableText, Iterable<TextFragment> {

}
