package rst.pdfbox.layout;

public enum Alignment {

	Left, Center, Right;
}
