package rst.pdfbox.layout;

import java.io.IOException;

public interface Area {

	float getWidth() throws IOException;

	float getHeight() throws IOException;
}
