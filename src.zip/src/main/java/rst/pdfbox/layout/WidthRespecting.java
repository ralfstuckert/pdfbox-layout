package rst.pdfbox.layout;

public interface WidthRespecting {

	float getMaxWidth();

	void setMaxWidth(float maxWidth);
}
